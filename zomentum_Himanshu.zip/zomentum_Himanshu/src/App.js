import { useCallback, useEffect, useReducer, useRef, useState } from 'react';
import './App.css';
import { List } from './List';

function App() {

  const [inputValue, setInputValue] = useState('');
  const [isListVisibility, setIsListVisibility] = useState(false);
  const [wordSearch, setWordSearch] = useState('');

  const [suggestedInputValue, setSuggestedInputValue] = useState('')

  const handleListValue = useCallback((upi) => {
    let currInputValue = inputValue;
    let newInputValue = `${currInputValue.split('@')[0]}@${upi}`
    setInputValue(newInputValue);
    setIsListVisibility(false);

  }, [inputValue])

  useEffect(() => {

    if (isListVisibility) {
      setTimeout(() => {
        let currValue = inputValue;
        let suggestedWord = '';
        let firstLi = listRef.current.querySelector('li').id;
        if(firstLi) {
          suggestedWord = `${currValue.split('@')[0]}@${firstLi}`;
        }
        
        setSuggestedInputValue(suggestedWord)
      })

    }

  }, [inputValue, isListVisibility])

  const listRef = useRef(null);

  // handle onchange
  const handleInputChange = (e) => {
    let currValue = e.target.value;

    if (currValue.indexOf('@') >= 0) {

      let wordToSearch = currValue.split('@')[1];
      setWordSearch(wordToSearch);
      setIsListVisibility(true);

    } else {
      setSuggestedInputValue('')
      setIsListVisibility(false);
    }

    setInputValue(currValue);
  }


  const handleKeyPress = (e) => {
    // console.log(e.keyCode)
    if(suggestedInputValue && e.keyCode === 39) {
      setInputValue(suggestedInputValue)
      setIsListVisibility(false);
    }
    return;
  }

  return (
    <div className="App">
      <div className='app__input__container'>
        <input
          value={suggestedInputValue}
          disabled={true}
          className='app__input-hidden'
        />
        <input
          onChange={handleInputChange}
          onKeyUp={handleKeyPress}
          value={inputValue}
          className='app__input app__input-visible' />
        <div ref={listRef} className='app__input app__suggestion__box'>
          {isListVisibility && <List wordToSearch={wordSearch} handleListValue={handleListValue} />}
        </div>
      </div>

    </div>
  );
}

export default App;

// 1. search
// improve UI
// selection of list item if we have
// multiple @ or special characters
// no suggestions if no list items
