import { UpiList } from "./UpiList";
import './List.css';
import { forwardRef, useEffect, useState } from "react";

export const List = forwardRef(({ wordToSearch, handleListValue }, ref) => {

    const [list, setList] = useState([]);

    const handleValue = (e) => {
        let currLi = e.target.closest('li');
        let currSelectedValue = currLi.id;
        handleListValue(currSelectedValue);
    }

    useEffect(() => {

        if(!wordToSearch.trim()) {
            setList(UpiList)
        } else {
            let filteredUpiList = UpiList.filter((upi) => (
                upi.indexOf(wordToSearch) >= 0
            ));

            setList(filteredUpiList);
        }

    }, [wordToSearch])

    return (
        <ol className="list" ref={ref} onClick={handleValue}>
            {
                list.map((upi) => (
                    <li className="list__item" key={upi} tabIndex='0' id={upi}>{upi}</li>
                ))
            }
        </ol>
    )
})